// Dovie Messenger iOS 앱 - 로컬 모드
document.addEventListener('DOMContentLoaded', function() {
    // 2초 후 로딩 화면 제거하고 앱 표시
    setTimeout(() => {
        document.getElementById('loading').style.display = 'none';
        document.getElementById('app').style.display = 'block';
        initializeApp();
    }, 2000);
});

function initializeApp() {
    // 기본 UI 생성
    document.getElementById('app').innerHTML = `
        <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
            <header style="background: linear-gradient(135deg, #8B5CF6, #3B82F6); color: white; padding: 20px; text-align: center;">
                <h1 style="margin: 0; font-size: 24px;">📱 Dovie Messenger</h1>
                <p style="margin: 10px 0 0 0; opacity: 0.9;">iOS 네이티브 앱</p>
            </header>
            
            <div id="login-section" style="padding: 40px 20px; text-align: center;">
                <div style="background: #f8f9fa; border-radius: 15px; padding: 30px; margin: 20px auto; max-width: 400px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
                    <h2 style="color: #333; margin-bottom: 20px;">로그인</h2>
                    <input type="text" id="username" placeholder="사용자명" style="width: 100%; padding: 15px; margin: 10px 0; border: 1px solid #ddd; border-radius: 8px; font-size: 16px;">
                    <button onclick="login()" style="width: 100%; padding: 15px; background: linear-gradient(135deg, #8B5CF6, #3B82F6); color: white; border: none; border-radius: 8px; font-size: 16px; font-weight: bold; margin-top: 10px;">
                        로그인
                    </button>
                </div>
            </div>
            
            <div id="chat-section" style="display: none; padding: 20px;">
                <div style="background: #f8f9fa; border-radius: 15px; padding: 20px; margin-bottom: 20px;">
                    <h3 style="color: #333; margin: 0 0 15px 0;">💬 채팅방</h3>
                    <div id="messages" style="height: 300px; overflow-y: auto; background: white; border-radius: 10px; padding: 15px; margin-bottom: 15px;">
                        <div style="color: #666; text-align: center; padding: 20px;">
                            Dovie Messenger에 오신 것을 환영합니다!<br>
                            실시간 채팅, 음성 메시지, 파일 공유가 가능합니다.
                        </div>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <input type="text" id="messageInput" placeholder="메시지 입력..." style="flex: 1; padding: 12px; border: 1px solid #ddd; border-radius: 8px; font-size: 14px;">
                        <button onclick="sendMessage()" style="padding: 12px 20px; background: #8B5CF6; color: white; border: none; border-radius: 8px; font-weight: bold;">
                            전송
                        </button>
                    </div>
                </div>
                
                <div style="background: #f8f9fa; border-radius: 15px; padding: 20px;">
                    <h3 style="color: #333; margin: 0 0 15px 0;">📋 기능</h3>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                        <button onclick="showFeature('연락처')" style="padding: 15px; background: white; border: 1px solid #ddd; border-radius: 8px; font-size: 14px;">
                            👥 연락처
                        </button>
                        <button onclick="showFeature('음성메시지')" style="padding: 15px; background: white; border: 1px solid #ddd; border-radius: 8px; font-size: 14px;">
                            🎤 음성메시지
                        </button>
                        <button onclick="showFeature('파일공유')" style="padding: 15px; background: white; border: 1px solid #ddd; border-radius: 8px; font-size: 14px;">
                            📎 파일공유
                        </button>
                        <button onclick="showFeature('설정')" style="padding: 15px; background: white; border: 1px solid #ddd; border-radius: 8px; font-size: 14px;">
                            ⚙️ 설정
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function login() {
    const username = document.getElementById('username').value;
    if (username.trim()) {
        document.getElementById('login-section').style.display = 'none';
        document.getElementById('chat-section').style.display = 'block';
        
        // 환영 메시지 추가
        addMessage('시스템', `${username}님, 환영합니다! 🎉`, true);
    } else {
        alert('사용자명을 입력해주세요.');
    }
}

function sendMessage() {
    const input = document.getElementById('messageInput');
    const message = input.value.trim();
    if (message) {
        const username = document.getElementById('username').value;
        addMessage(username, message, false);
        input.value = '';
        
        // 자동 응답 (데모용)
        setTimeout(() => {
            addMessage('Dovie AI', `"${message}"에 대한 응답입니다. 실제 서버 연결 시 실시간 채팅이 가능합니다.`, true);
        }, 1000);
    }
}

function addMessage(sender, text, isSystem) {
    const messages = document.getElementById('messages');
    const messageDiv = document.createElement('div');
    messageDiv.style.cssText = `
        margin-bottom: 10px; 
        padding: 10px; 
        border-radius: 8px; 
        ${isSystem ? 'background: #e3f2fd; border-left: 3px solid #2196f3;' : 'background: #f5f5f5;'}
    `;
    messageDiv.innerHTML = `
        <div style="font-weight: bold; color: ${isSystem ? '#1976d2' : '#333'}; margin-bottom: 5px;">
            ${sender}
        </div>
        <div style="color: #555;">${text}</div>
    `;
    messages.appendChild(messageDiv);
    messages.scrollTop = messages.scrollHeight;
}

function showFeature(feature) {
    alert(`${feature} 기능이 선택되었습니다.\n\n실제 앱에서는 다음이 가능합니다:\n\n• 실시간 채팅\n• 음성 메시지 녹음\n• 파일 업로드/다운로드\n• 연락처 관리\n• 푸시 알림\n• QR 코드 공유`);
}

// Enter 키로 메시지 전송
document.addEventListener('keypress', function(e) {
    if (e.key === 'Enter' && document.getElementById('messageInput') === document.activeElement) {
        sendMessage();
    }
});