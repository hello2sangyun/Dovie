// Dovie Messenger iOS 네이티브 앱
document.addEventListener('DOMContentLoaded', function() {
    console.log('iOS 네이티브 앱 시작');
    loadDovieMessenger();
});

function loadDovieMessenger() {
    console.log('Dovie Messenger 로딩 중...');
    
    // 로딩 화면 표시
    document.body.innerHTML = `
        <div id="loadingScreen" style="
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            font-family: -apple-system, BlinkMacSystemFont, sans-serif;
            text-align: center;
        ">
            <div style="
                width: 80px;
                height: 80px;
                margin-bottom: 20px;
                background: rgba(255,255,255,0.2);
                border-radius: 20px;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 40px;
            ">📱</div>
            <h1 style="margin: 0 0 10px 0;">Dovie Messenger</h1>
            <p style="margin: 0 0 30px 0; opacity: 0.8;">로딩 중...</p>
            <div style="
                width: 40px;
                height: 40px;
                border: 4px solid rgba(255,255,255,0.3);
                border-top: 4px solid white;
                border-radius: 50%;
                animation: spin 1s linear infinite;
            "></div>
        </div>
        <style>
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
        </style>
    `;
    
    // 2초 후 서버 콘텐츠 로드
    setTimeout(() => {
        const serverUrl = 'https://dovie-hello2sangyun.replit.app';
        
        // iframe으로 서버 콘텐츠 로드 (네이티브 앱 내에서 실행)
        document.body.innerHTML = `
            <iframe 
                id="dovieFrame"
                src="${serverUrl}" 
                style="
                    width: 100%;
                    height: 100vh;
                    border: none;
                    margin: 0;
                    padding: 0;
                "
                onload="onDovieLoaded()"
                onerror="showErrorMessage()"
            ></iframe>
        `;
        
        // 푸시 알림 초기화
        initializePushNotifications();
    }, 2000);
}

// Dovie 로드 완료 후 호출
function onDovieLoaded() {
    console.log('🚀 Dovie Messenger 로드 완료');
    
    // 서버 연결 테스트
    testServerConnection();
    
    // 푸시 알림 초기화
    initializePushNotifications();
    
    // 네이티브 마이크 권한 초기화
    initializeMicrophonePermission();
    
    // 앱 활성화 이벤트 리스너 설정
    window.addEventListener('appDidBecomeActive', function() {
        console.log('📱 앱이 활성화됨 - 뱃지 클리어 및 상태 동기화');
        updateAppBadge(); // 뱃지 상태 서버와 동기화
    });
    
    // 주기적으로 뱃지 업데이트
    updateAppBadge(); // 즉시 한번 실행
    setInterval(updateAppBadge, 30000); // 30초마다
    
    console.log('✅ 모든 초기화 완료');
}

// 서버 연결 테스트 함수
function testServerConnection() {
    const serverUrl = 'https://dovie-hello2sangyun.replit.app';
    
    console.log('🌐 서버 연결 테스트 시작...');
    
    // 1. 안읽은 메시지 확인
    fetch(`${serverUrl}/api/unread-counts`, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'X-User-Id': '117',
            'X-Capacitor-Platform': 'ios'
        }
    })
    .then(response => {
        console.log('✅ 서버 연결 성공 - 상태 코드:', response.status);
        return response.json();
    })
    .then(data => {
        console.log('✅ 서버 응답 데이터:', data);
        console.log('📊 안읽은 메시지 카운트:', data.unreadCounts ? data.unreadCounts.length : 0);
        
        // 총 안읽은 메시지 수 계산
        const totalUnread = data.unreadCounts ? 
            data.unreadCounts.reduce((sum, room) => sum + room.unreadCount, 0) : 0;
        console.log('📱 총 안읽은 메시지:', totalUnread);
        
        // 앱 배지 업데이트
        updateAppBadgeWithCount(totalUnread);
    })
    .catch(error => {
        console.error('❌ 서버 연결 실패:', error);
        console.error('네트워크 상태를 확인해주세요');
    });
    
    // 2. iOS 디바이스 토큰 등록 상태 확인
    fetch(`${serverUrl}/api/ios-device-status`, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'X-User-Id': '117',
            'X-Capacitor-Platform': 'ios'
        }
    })
    .then(response => response.json())
    .then(data => {
        console.log('📱 iOS 디바이스 등록 상태:', data);
        console.log('데이터베이스 등록 디바이스:', data.totalDevicesInDB);
        console.log('메모리 등록 디바이스:', data.memoryDevices);
        console.log('등록된 사용자:', data.registeredUsers);
        
        if (data.totalDevicesInDB === 0) {
            console.log('⚠️ iOS 디바이스 토큰이 등록되지 않았습니다. 푸시 알림 등록을 시도합니다.');
            // 푸시 알림 재등록 시도
            setTimeout(() => {
                initializePushNotifications();
            }, 2000);
        }
    })
    .catch(error => {
        console.error('❌ iOS 디바이스 상태 확인 실패:', error);
    });
}

// iOS 네이티브 푸시 알림 초기화
function initializePushNotifications() {
    console.log('푸시 알림 초기화 시도 중...');
    
    // Capacitor 플러그인 확인
    if (typeof window.Capacitor === 'undefined') {
        console.log('Capacitor 플러그인 로딩 대기 중...');
        setTimeout(initializePushNotifications, 1000);
        return;
    }
    
    if (!window.Capacitor.isNativePlatform()) {
        console.log('네이티브 플랫폼이 아님');
        return;
    }
    
    console.log('iOS 네이티브 푸시 알림 초기화 중...');
    
    // 푸시 알림 플러그인 확인
    const PushNotifications = window.Capacitor.Plugins.PushNotifications;
    if (!PushNotifications) {
        console.error('PushNotifications 플러그인을 찾을 수 없음');
        return;
    }
    
    // AppDelegate에서 전달되는 네이티브 디바이스 토큰 이벤트 리스너
    window.addEventListener('deviceTokenReceived', function(event) {
        const token = event.detail.token;
        console.log('📱 AppDelegate에서 네이티브 토큰 수신:', token);
        console.log('토큰 길이:', token.length, '문자');
        
        // 즉시 서버에 등록
        registerDeviceTokenToServer(token);
    });
    
    // 푸시 알림 클릭 이벤트 리스너 (AppDelegate에서 전달)
    window.addEventListener('notificationClicked', function(event) {
        console.log('👆 네이티브 푸시 알림 클릭됨:', event.detail);
        const data = event.detail;
        if (data && data.chatRoomId) {
            navigateToChat(data.chatRoomId);
        }
        updateAppBadge(); // 뱃지 업데이트
    });
    
    // 현재 상태 정보 출력
    console.log('📊 Capacitor 플러그인 상태:', {
        plugins: Object.keys(window.Capacitor.Plugins),
        platform: window.Capacitor.getPlatform(),
        isNative: window.Capacitor.isNativePlatform()
    });
    
    // 디바이스 토큰 등록 성공 리스너 먼저 설정
    PushNotifications.addListener('registration', (token) => {
        console.log('🎯 푸시 토큰 등록 성공!');
        console.log('토큰 값:', token.value);
        console.log('토큰 길이:', token.value ? token.value.length : 0);
        
        if (token.value && token.value.length > 0) {
            console.log('✅ 유효한 디바이스 토큰 수신 - 서버 전송 시작');
            sendTokenToServer(token.value);
        } else {
            console.error('❌ 빈 디바이스 토큰 수신');
        }
    });

    // 디바이스 토큰 등록 실패 리스너
    PushNotifications.addListener('registrationError', (error) => {
        console.error('❌ 푸시 토큰 등록 실패:', error);
        console.error('오류 세부사항:', JSON.stringify(error, null, 2));
    });
    
    // 권한 요청 및 등록 프로세스
    console.log('📱 푸시 알림 권한 요청 시작...');
    
    PushNotifications.requestPermissions()
        .then(result => {
            console.log('✅ 권한 요청 완료:', result);
            
            if (result.receive === 'granted') {
                console.log('✅ 푸시 알림 권한 허용됨 - 등록 진행');
                return PushNotifications.register();
            } else {
                console.log('⚠️ 푸시 알림 권한 상태:', result.receive);
                // 권한이 없어도 등록 시도
                console.log('등록 시도 계속 진행...');
                return PushNotifications.register();
            }
        })
        .then(() => {
            console.log('📱 디바이스 토큰 등록 요청 완료 - 응답 대기 중...');
        })
        .catch(error => {
            console.error('❌ 푸시 알림 설정 실패:', error);
            
            // 오류가 있어도 직접 등록 시도
            console.log('직접 등록 시도...');
            try {
                PushNotifications.register();
            } catch (e) {
                console.error('직접 등록도 실패:', e);
            }
        });

    // 푸시 알림 수신 (앱이 활성 상태일 때)
    PushNotifications.addListener('pushNotificationReceived', (notification) => {
        console.log('푸시 알림 수신:', notification);
        updateAppBadge();
    });

    // 푸시 알림 클릭 (앱이 비활성 상태에서 알림 클릭)
    PushNotifications.addListener('pushNotificationActionPerformed', (notification) => {
        console.log('푸시 알림 클릭:', notification);
        const data = notification.notification.data;
        if (data && data.chatRoomId) {
            navigateToChat(data.chatRoomId);
        }
    });
}

// 네이티브 마이크 권한 초기화 (PWA 권한 요청 제거)
function initializeMicrophonePermission() {
    if (window.Capacitor && window.Capacitor.isNativePlatform()) {
        console.log('🎤 네이티브 마이크 권한 초기화');
        // 네이티브 앱에서는 Info.plist에서 권한 설정됨
        // 별도 권한 요청 팝업 없이 자동 처리
        console.log('✅ 네이티브 마이크 권한 설정 완료');
    } else {
        console.log('⚠️ 네이티브 환경이 아님 - 마이크 권한 스킵');
    }
}

// iOS 디바이스 토큰을 서버에 등록하는 함수
async function registerDeviceTokenToServer(deviceToken) {
    const serverUrl = 'https://dovie-hello2sangyun.replit.app';
    const userId = '117'; // 테스트 사용자 ID
    
    console.log('🚀 디바이스 토큰 서버 등록 시작');
    console.log('토큰:', deviceToken);
    console.log('서버 URL:', serverUrl);
    console.log('사용자 ID:', userId);
    
    try {
        const response = await fetch(`${serverUrl}/api/ios-device-token`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-User-Id': userId,
                'X-Capacitor-Platform': 'ios'
            },
            body: JSON.stringify({
                deviceToken: deviceToken,
                platform: 'ios',
                userId: parseInt(userId)
            })
        });
        
        console.log('서버 응답 상태:', response.status);
        
        if (response.ok) {
            const result = await response.json();
            console.log('✅ 디바이스 토큰 등록 성공:', result);
            console.log('등록된 토큰 ID:', result.tokenId);
            
            // 등록 성공 후 뱃지 동기화
            updateAppBadge();
            
            return result;
        } else {
            const errorText = await response.text();
            console.error('❌ 디바이스 토큰 등록 실패:', response.status, errorText);
            throw new Error(`서버 응답 오류: ${response.status} - ${errorText}`);
        }
    } catch (error) {
        console.error('❌ 네트워크 오류:', error);
        console.error('3초 후 재시도...');
        
        // 3초 후 재시도
        setTimeout(() => {
            console.log('🔄 디바이스 토큰 등록 재시도');
            registerDeviceTokenToServer(deviceToken);
        }, 3000);
        
        throw error;
    }
}

// sendTokenToServer 함수 (registerDeviceTokenToServer의 별칭)
async function sendTokenToServer(deviceToken) {
    console.log('📤 sendTokenToServer 호출됨:', deviceToken);
    return await registerDeviceTokenToServer(deviceToken);
}

// 서버에 푸시 토큰 전송
function sendTokenToServer(token) {
    const serverUrl = 'https://dovie-hello2sangyun.replit.app';
    
    console.log('🚀 서버에 푸시 토큰 전송 시작');
    console.log('토큰 앞부분:', token.substring(0, 20) + '...');
    console.log('토큰 전체 길이:', token.length);
    
    const requestData = {
        deviceToken: token,
        platform: 'ios',
        bundleId: 'com.dovie.messenger',
        userId: 117
    };
    
    console.log('📤 전송할 데이터:', JSON.stringify(requestData, null, 2));
    
    fetch(`${serverUrl}/api/ios-device-token`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-User-Id': '117',
            'X-Capacitor-Platform': 'ios'
        },
        body: JSON.stringify(requestData)
    })
    .then(response => {
        console.log('📨 서버 응답 상태:', response.status, response.statusText);
        
        if (!response.ok) {
            console.error('❌ 서버 응답 실패:', response.status, response.statusText);
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        return response.json();
    })
    .then(data => {
        console.log('✅ 푸시 토큰 등록 성공!');
        console.log('서버 응답:', data);
        
        // 등록 성공 후 즉시 상태 확인
        setTimeout(() => {
            checkDeviceTokenStatus();
        }, 1000);
    })
    .catch(error => {
        console.error('❌ 푸시 토큰 전송 실패:', error);
        console.error('에러 세부사항:', {
            message: error.message,
            stack: error.stack
        });
        
        // 실패 시 재시도
        console.log('⏳ 3초 후 재시도...');
        setTimeout(() => {
            console.log('🔄 푸시 토큰 재전송 시도');
            sendTokenToServer(token);
        }, 3000);
    });
}

// 디바이스 토큰 등록 상태 확인
function checkDeviceTokenStatus() {
    const serverUrl = 'https://dovie-hello2sangyun.replit.app';
    
    console.log('🔍 디바이스 토큰 등록 상태 확인 중...');
    
    fetch(`${serverUrl}/api/ios-device-status`, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'X-User-Id': '117'
        }
    })
    .then(response => response.json())
    .then(data => {
        console.log('📊 디바이스 등록 상태:', data);
        
        if (data.totalDevicesInDB > 0) {
            console.log('✅ 디바이스 토큰이 성공적으로 등록되었습니다!');
            console.log('등록된 디바이스 수:', data.totalDevicesInDB);
        } else {
            console.log('⚠️ 디바이스 토큰이 아직 등록되지 않았습니다.');
        }
    })
    .catch(error => {
        console.error('❌ 상태 확인 실패:', error);
    });
}

// 테스트 푸시 알림 발송 (필요시 사용)
function sendTestPushNotification() {
    const serverUrl = 'https://dovie-hello2sangyun.replit.app';
    
    console.log('📱 테스트 푸시 알림 발송 요청...');
    
    fetch(`${serverUrl}/api/test-ios-push`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-User-Id': '117',
            'X-Capacitor-Platform': 'ios'
        },
        body: JSON.stringify({
            message: '네이티브 iOS 앱 푸시 알림 테스트 성공!',
            title: 'Dovie Messenger',
            badge: 1
        })
    })
    .then(response => {
        console.log('📨 테스트 푸시 알림 응답 상태:', response.status);
        return response.json();
    })
    .then(data => {
        console.log('✅ 테스트 푸시 알림 발송 성공:', data);
    })
    .catch(error => {
        console.error('❌ 테스트 푸시 알림 발송 실패:', error);
    });
}

// 앱 뱃지 업데이트
function updateAppBadge() {
    const serverUrl = 'https://dovie-hello2sangyun.replit.app';
    
    console.log('뱃지 업데이트 요청 중...');
    
    fetch(`${serverUrl}/api/unread-counts`, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'X-User-Id': '117',
            'X-Capacitor-Platform': 'ios'
        },
        mode: 'cors'
    })
    .then(response => {
        console.log('✅ 서버 연결 성공 - 상태 코드:', response.status);
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        return response.json();
    })
    .then(data => {
        console.log('안읽은 메시지 데이터:', data);
        
        let totalUnread = 0;
        if (data.unreadCounts && Array.isArray(data.unreadCounts)) {
            totalUnread = data.unreadCounts.reduce((sum, item) => sum + (item.unreadCount || 0), 0);
        }
        
        console.log('총 안읽은 메시지 수:', totalUnread);
        
        // iOS 네이티브 뱃지 설정 (여러 방법 시도)
        if (window.Capacitor && window.Capacitor.isNativePlatform()) {
            // 방법 1: Capacitor PushNotifications 플러그인
            const PushNotifications = window.Capacitor.Plugins.PushNotifications;
            if (PushNotifications && PushNotifications.setBadgeCount) {
                PushNotifications.setBadgeCount({ count: totalUnread })
                    .then(() => {
                        console.log('✅ Capacitor 뱃지 업데이트 성공:', totalUnread);
                    })
                    .catch(error => {
                        console.error('❌ Capacitor 뱃지 업데이트 실패:', error);
                    });
            }
            
            // 방법 2: 네이티브 코드 호출 (AppDelegate를 통한 직접 설정)
            const nativeScript = `
                if (typeof window.webkit !== 'undefined' && window.webkit.messageHandlers) {
                    try {
                        const appDelegate = UIApplication.shared.delegate;
                        UIApplication.shared.applicationIconBadgeNumber = ${totalUnread};
                        console.log('네이티브 뱃지 직접 설정:', ${totalUnread});
                    } catch (e) {
                        console.log('네이티브 뱃지 설정 시도 실패:', e);
                    }
                }
            `;
            
            try {
                eval(nativeScript);
            } catch (e) {
                console.log('네이티브 스크립트 실행 불가:', e.message);
            }
            
            // 방법 3: JavaScript를 통한 뱃지 설정 알림
            window.dispatchEvent(new CustomEvent('updateBadgeCount', { 
                detail: { count: totalUnread } 
            }));
            
        } else {
            console.log('Capacitor 네이티브 플랫폼이 아님');
        }
        
        // 뱃지 업데이트 성공 로그
        console.log(`뱃지 업데이트 완료: ${totalUnread}개의 안읽은 메시지`);
    })
    .catch(error => {
        console.error('❌ 뱃지 업데이트 실패:', error);
        console.error('에러 상세:', error.message || 'Load failed');
        
        // 네트워크 오류 시 기본 뱃지 처리
        if (window.Capacitor && window.Capacitor.isNativePlatform()) {
            const PushNotifications = window.Capacitor.Plugins.PushNotifications;
            if (PushNotifications && PushNotifications.setBadgeCount) {
                PushNotifications.setBadgeCount({ count: 0 })
                    .then(() => {
                        console.log('✅ 기본 뱃지 클리어 완료');
                    })
                    .catch(badgeError => {
                        console.error('❌ 기본 뱃지 클리어 실패:', badgeError);
                    });
            }
        }
    });
}

// 채팅방으로 이동
function navigateToChat(chatRoomId) {
    console.log('채팅방으로 이동:', chatRoomId);
    
    const iframe = document.getElementById('dovieFrame');
    if (iframe && iframe.contentWindow) {
        try {
            // iframe 내부의 URL 변경
            const newUrl = `https://dovie-hello2sangyun.replit.app/#/chat/${chatRoomId}`;
            iframe.src = newUrl;
        } catch (error) {
            console.error('채팅방 이동 실패:', error);
        }
    }
}

function showErrorMessage() {
    document.body.innerHTML = `
        <div style="
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            font-family: -apple-system, BlinkMacSystemFont, sans-serif;
            text-align: center;
            padding: 20px;
        ">
            <div style="
                background: rgba(255,255,255,0.1);
                padding: 40px;
                border-radius: 20px;
                backdrop-filter: blur(10px);
            ">
                <h1 style="margin: 0 0 20px 0;">연결 실패</h1>
                <p style="margin: 0;">서버에 연결할 수 없습니다.</p>
                <p style="margin: 10px 0 0 0; font-size: 14px; opacity: 0.8;">네트워크 연결을 확인해주세요.</p>
                <button onclick="loadDovieMessenger()" style="
                    margin-top: 20px;
                    padding: 12px 24px;
                    background: rgba(255,255,255,0.2);
                    border: none;
                    border-radius: 10px;
                    color: white;
                    font-weight: bold;
                    cursor: pointer;
                ">다시 시도</button>
            </div>
        </div>
    `;
}

// 앱 배지 업데이트 함수
function updateAppBadgeWithCount(count) {
    console.log('📱 앱 배지 업데이트 시도:', count);
    
    if (!window.Capacitor || !window.Capacitor.isNativePlatform()) {
        console.log('⚠️ 네이티브 플랫폼이 아님 - 배지 업데이트 스킵');
        return;
    }
    
    try {
        const PushNotifications = window.Capacitor.Plugins.PushNotifications;
        
        if (PushNotifications && PushNotifications.setBadgeCount) {
            PushNotifications.setBadgeCount({ count: count })
                .then(() => {
                    console.log('✅ 네이티브 앱 배지 업데이트 성공:', count);
                })
                .catch(error => {
                    console.error('❌ 네이티브 앱 배지 업데이트 실패:', error);
                    
                    // 대안 방법: 커스텀 이벤트로 AppDelegate에 알림
                    try {
                        const badgeEvent = new CustomEvent('updateBadge', { 
                            detail: { count: count } 
                        });
                        window.dispatchEvent(badgeEvent);
                        console.log('커스텀 이벤트로 배지 업데이트 요청 전송');
                    } catch (e) {
                        console.error('커스텀 이벤트 실패:', e);
                    }
                });
        } else {
            console.log('⚠️ PushNotifications.setBadgeCount 미지원');
            
            // 대안 방법
            try {
                const badgeEvent = new CustomEvent('updateBadge', { 
                    detail: { count: count } 
                });
                window.dispatchEvent(badgeEvent);
                console.log('커스텀 이벤트로 배지 업데이트 요청 전송');
            } catch (e) {
                console.error('커스텀 이벤트 실패:', e);
            }
        }
    } catch (error) {
        console.error('❌ 배지 업데이트 전체 실패:', error);
    }
}