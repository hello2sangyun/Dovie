// Cordova placeholder for Capacitor app
console.log('Cordova compatibility loaded');