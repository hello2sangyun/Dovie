// Dovie Messenger iOS 앱 - 서버 연결형
document.addEventListener('DOMContentLoaded', function() {
    // 서버 연결 확인 후 리다이렉트
    setTimeout(() => {
        window.location.href = 'https://vault-messenger-1-hello2sangyun.replit.app';
    }, 1000);
});