// Dovie Messenger iOS 네이티브 앱
document.addEventListener('DOMContentLoaded', function() {
    console.log('iOS 네이티브 앱 시작');
    loadDovieMessenger();
});

function loadDovieMessenger() {
    console.log('Dovie Messenger 로딩 중...');
    
    // 로딩 화면 표시
    document.body.innerHTML = `
        <div id="loadingScreen" style="
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            font-family: -apple-system, BlinkMacSystemFont, sans-serif;
            text-align: center;
        ">
            <div style="
                width: 80px;
                height: 80px;
                margin-bottom: 20px;
                background: rgba(255,255,255,0.2);
                border-radius: 20px;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 40px;
            ">📱</div>
            <h1 style="margin: 0 0 10px 0;">Dovie Messenger</h1>
            <p style="margin: 0 0 30px 0; opacity: 0.8;">로딩 중...</p>
            <div style="
                width: 40px;
                height: 40px;
                border: 4px solid rgba(255,255,255,0.3);
                border-top: 4px solid white;
                border-radius: 50%;
                animation: spin 1s linear infinite;
            "></div>
        </div>
        <style>
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
        </style>
    `;
    
    // 2초 후 서버 콘텐츠 로드
    setTimeout(() => {
        const serverUrl = 'https://dovie-hello2sangyun.replit.app';
        
        // iframe으로 서버 콘텐츠 로드 (네이티브 앱 내에서 실행)
        document.body.innerHTML = `
            <iframe 
                id="dovieFrame"
                src="${serverUrl}" 
                style="
                    width: 100%;
                    height: 100vh;
                    border: none;
                    margin: 0;
                    padding: 0;
                "
                onload="onDovieLoaded()"
                onerror="showErrorMessage()"
            ></iframe>
        `;
        
        // 푸시 알림 초기화
        initializePushNotifications();
    }, 2000);
}

// Dovie 로드 완료 후 호출
function onDovieLoaded() {
    console.log('🚀 Dovie Messenger 로드 완료');
    
    // 서버 연결 테스트
    testServerConnection();
    
    // 푸시 알림 초기화
    initializePushNotifications();
    
    // 네이티브 마이크 권한 초기화
    initializeMicrophonePermission();
    
    // 앱 활성화 이벤트 리스너 설정
    window.addEventListener('appDidBecomeActive', function() {
        console.log('📱 앱이 활성화됨 - 뱃지 클리어 및 상태 동기화');
        updateAppBadge(); // 뱃지 상태 서버와 동기화
    });
    
    // 주기적으로 뱃지 업데이트
    updateAppBadge(); // 즉시 한번 실행
    setInterval(updateAppBadge, 30000); // 30초마다
    
    console.log('✅ 모든 초기화 완료');
}

// 서버 연결 테스트 함수
function testServerConnection() {
    const serverUrl = 'https://dovie-hello2sangyun.replit.app';
    
    console.log('🌐 서버 연결 테스트 시작...');
    
    fetch(`${serverUrl}/api/unread-counts`, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'X-User-Id': '117',
            'X-Capacitor-Platform': 'ios'
        }
    })
    .then(response => {
        console.log('✅ 서버 연결 성공 - 상태 코드:', response.status);
        return response.json();
    })
    .then(data => {
        console.log('✅ 서버 응답 데이터:', data);
        console.log('📊 안읽은 메시지 카운트:', data.unreadCounts ? data.unreadCounts.length : 0);
    })
    .catch(error => {
        console.error('❌ 서버 연결 실패:', error);
        console.error('네트워크 상태를 확인해주세요');
    });
}

// iOS 네이티브 푸시 알림 초기화
function initializePushNotifications() {
    console.log('푸시 알림 초기화 시도 중...');
    
    // Capacitor 플러그인 확인
    if (typeof window.Capacitor === 'undefined') {
        console.log('Capacitor 플러그인 로딩 대기 중...');
        setTimeout(initializePushNotifications, 1000);
        return;
    }
    
    if (!window.Capacitor.isNativePlatform()) {
        console.log('네이티브 플랫폼이 아님');
        return;
    }
    
    console.log('iOS 네이티브 푸시 알림 초기화 중...');
    
    // 푸시 알림 플러그인 확인
    const PushNotifications = window.Capacitor.Plugins.PushNotifications;
    if (!PushNotifications) {
        console.error('PushNotifications 플러그인을 찾을 수 없음');
        return;
    }
    
    // AppDelegate에서 전달되는 네이티브 디바이스 토큰 이벤트 리스너
    window.addEventListener('deviceTokenReceived', function(event) {
        const token = event.detail.token;
        console.log('📱 AppDelegate에서 네이티브 토큰 수신:', token);
        sendTokenToServer(token);
    });
    
    // 푸시 알림 클릭 이벤트 리스너 (AppDelegate에서 전달)
    window.addEventListener('notificationClicked', function(event) {
        console.log('👆 네이티브 푸시 알림 클릭됨:', event.detail);
        const data = event.detail;
        if (data && data.chatRoomId) {
            navigateToChat(data.chatRoomId);
        }
        updateAppBadge(); // 뱃지 업데이트
    });
    
    // 권한 요청 없이 직접 등록 (네이티브 앱에서는 자동 처리)
    console.log('네이티브 앱 푸시 알림 등록 시작');
    PushNotifications.register();

    // 디바이스 토큰 등록 성공
    PushNotifications.addListener('registration', (token) => {
        console.log('푸시 토큰 등록 성공:', token.value);
        sendTokenToServer(token.value);
    });

    // 디바이스 토큰 등록 실패
    PushNotifications.addListener('registrationError', (error) => {
        console.error('푸시 토큰 등록 실패:', error);
    });

    // 푸시 알림 수신 (앱이 활성 상태일 때)
    PushNotifications.addListener('pushNotificationReceived', (notification) => {
        console.log('푸시 알림 수신:', notification);
        updateAppBadge();
    });

    // 푸시 알림 클릭 (앱이 비활성 상태에서 알림 클릭)
    PushNotifications.addListener('pushNotificationActionPerformed', (notification) => {
        console.log('푸시 알림 클릭:', notification);
        const data = notification.notification.data;
        if (data && data.chatRoomId) {
            navigateToChat(data.chatRoomId);
        }
    });
}

// 네이티브 마이크 권한 초기화 (PWA 권한 요청 제거)
function initializeMicrophonePermission() {
    if (window.Capacitor && window.Capacitor.isNativePlatform()) {
        console.log('🎤 네이티브 마이크 권한 초기화');
        // 네이티브 앱에서는 Info.plist에서 권한 설정됨
        // 별도 권한 요청 팝업 없이 자동 처리
        console.log('✅ 네이티브 마이크 권한 설정 완료');
    } else {
        console.log('⚠️ 네이티브 환경이 아님 - 마이크 권한 스킵');
    }
}

// 서버에 푸시 토큰 전송
function sendTokenToServer(token) {
    const serverUrl = 'https://dovie-hello2sangyun.replit.app';
    
    console.log('서버에 푸시 토큰 전송 중:', token.substring(0, 20) + '...');
    
    const requestData = {
        deviceToken: token,
        platform: 'ios',
        bundleId: 'com.dovie.messenger',
        userId: 117 // HOLY 사용자 ID
    };
    
    console.log('전송할 데이터:', JSON.stringify(requestData, null, 2));
    
    fetch(`${serverUrl}/api/ios-device-token`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-User-Id': '117',
            'X-Capacitor-Platform': 'ios'
        },
        body: JSON.stringify(requestData)
    })
    .then(response => {
        console.log('푸시 토큰 전송 응답 상태:', response.status);
        console.log('응답 헤더:', response.headers);
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        return response.json();
    })
    .then(data => {
        console.log('✅ 푸시 토큰 서버 전송 성공:', data);
        console.log('등록된 총 디바이스 수:', data.totalDevices);
        
        // 토큰 등록 성공 후 테스트 푸시 발송
        sendTestPushNotification();
    })
    .catch(error => {
        console.error('❌ 푸시 토큰 서버 전송 실패:', error);
        console.error('에러 상세:', error.message);
    });
}

// 테스트 푸시 알림 발송
function sendTestPushNotification() {
    const serverUrl = 'https://dovie-hello2sangyun.replit.app';
    
    console.log('테스트 푸시 알림 발송 요청...');
    
    fetch(`${serverUrl}/api/test-ios-push`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-User-Id': '117',
            'X-Capacitor-Platform': 'ios'
        },
        body: JSON.stringify({
            message: '네이티브 iOS 앱 푸시 알림 테스트 성공!',
            title: 'Dovie Messenger',
            badge: 1
        })
    })
    .then(response => {
        console.log('테스트 푸시 알림 응답 상태:', response.status);
        return response.json();
    })
    .then(data => {
        console.log('✅ 테스트 푸시 알림 발송 성공:', data);
    })
    .catch(error => {
        console.error('❌ 테스트 푸시 알림 발송 실패:', error);
    });
}

// 앱 뱃지 업데이트
function updateAppBadge() {
    const serverUrl = 'https://dovie-hello2sangyun.replit.app';
    
    console.log('뱃지 업데이트 요청 중...');
    
    fetch(`${serverUrl}/api/unread-counts`, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'X-User-Id': '117',
            'X-Capacitor-Platform': 'ios'
        },
        credentials: 'include'
    })
    .then(response => {
        console.log('뱃지 API 응답 상태:', response.status);
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        return response.json();
    })
    .then(data => {
        console.log('안읽은 메시지 데이터:', data);
        
        let totalUnread = 0;
        if (data.unreadCounts && Array.isArray(data.unreadCounts)) {
            totalUnread = data.unreadCounts.reduce((sum, item) => sum + (item.unreadCount || 0), 0);
        }
        
        console.log('총 안읽은 메시지 수:', totalUnread);
        
        // iOS 네이티브 뱃지 설정 (여러 방법 시도)
        if (window.Capacitor && window.Capacitor.isNativePlatform()) {
            // 방법 1: Capacitor PushNotifications 플러그인
            const PushNotifications = window.Capacitor.Plugins.PushNotifications;
            if (PushNotifications && PushNotifications.setBadgeCount) {
                PushNotifications.setBadgeCount({ count: totalUnread })
                    .then(() => {
                        console.log('✅ Capacitor 뱃지 업데이트 성공:', totalUnread);
                    })
                    .catch(error => {
                        console.error('❌ Capacitor 뱃지 업데이트 실패:', error);
                    });
            }
            
            // 방법 2: 네이티브 코드 호출 (AppDelegate를 통한 직접 설정)
            const nativeScript = `
                if (typeof window.webkit !== 'undefined' && window.webkit.messageHandlers) {
                    try {
                        const appDelegate = UIApplication.shared.delegate;
                        UIApplication.shared.applicationIconBadgeNumber = ${totalUnread};
                        console.log('네이티브 뱃지 직접 설정:', ${totalUnread});
                    } catch (e) {
                        console.log('네이티브 뱃지 설정 시도 실패:', e);
                    }
                }
            `;
            
            try {
                eval(nativeScript);
            } catch (e) {
                console.log('네이티브 스크립트 실행 불가:', e.message);
            }
            
            // 방법 3: JavaScript를 통한 뱃지 설정 알림
            window.dispatchEvent(new CustomEvent('updateBadgeCount', { 
                detail: { count: totalUnread } 
            }));
            
        } else {
            console.log('Capacitor 네이티브 플랫폼이 아님');
        }
        
        // 뱃지 업데이트 성공 로그
        console.log(`뱃지 업데이트 완료: ${totalUnread}개의 안읽은 메시지`);
    })
    .catch(error => {
        console.error('❌ 뱃지 업데이트 실패:', error);
        console.error('에러 상세:', error.message);
    });
}

// 채팅방으로 이동
function navigateToChat(chatRoomId) {
    console.log('채팅방으로 이동:', chatRoomId);
    
    const iframe = document.getElementById('dovieFrame');
    if (iframe && iframe.contentWindow) {
        try {
            // iframe 내부의 URL 변경
            const newUrl = `https://dovie-hello2sangyun.replit.app/#/chat/${chatRoomId}`;
            iframe.src = newUrl;
        } catch (error) {
            console.error('채팅방 이동 실패:', error);
        }
    }
}

function showErrorMessage() {
    document.body.innerHTML = `
        <div style="
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            font-family: -apple-system, BlinkMacSystemFont, sans-serif;
            text-align: center;
            padding: 20px;
        ">
            <div style="
                background: rgba(255,255,255,0.1);
                padding: 40px;
                border-radius: 20px;
                backdrop-filter: blur(10px);
            ">
                <h1 style="margin: 0 0 20px 0;">연결 실패</h1>
                <p style="margin: 0;">서버에 연결할 수 없습니다.</p>
                <p style="margin: 10px 0 0 0; font-size: 14px; opacity: 0.8;">네트워크 연결을 확인해주세요.</p>
                <button onclick="loadDovieMessenger()" style="
                    margin-top: 20px;
                    padding: 12px 24px;
                    background: rgba(255,255,255,0.2);
                    border: none;
                    border-radius: 10px;
                    color: white;
                    font-weight: bold;
                    cursor: pointer;
                ">다시 시도</button>
            </div>
        </div>
    `;
}