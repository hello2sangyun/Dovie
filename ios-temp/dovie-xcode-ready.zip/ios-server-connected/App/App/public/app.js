// Dovie Messenger iOS 네이티브 앱
document.addEventListener('DOMContentLoaded', function() {
    console.log('iOS 네이티브 앱 시작');
    loadDovieMessenger();
});

function loadDovieMessenger() {
    console.log('Dovie Messenger 로딩 중...');
    
    // 로딩 화면 표시
    document.body.innerHTML = `
        <div id="loadingScreen" style="
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            font-family: -apple-system, BlinkMacSystemFont, sans-serif;
            text-align: center;
        ">
            <div style="
                width: 80px;
                height: 80px;
                margin-bottom: 20px;
                background: rgba(255,255,255,0.2);
                border-radius: 20px;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 40px;
            ">📱</div>
            <h1 style="margin: 0 0 10px 0;">Dovie Messenger</h1>
            <p style="margin: 0 0 30px 0; opacity: 0.8;">로딩 중...</p>
            <div style="
                width: 40px;
                height: 40px;
                border: 4px solid rgba(255,255,255,0.3);
                border-top: 4px solid white;
                border-radius: 50%;
                animation: spin 1s linear infinite;
            "></div>
        </div>
        <style>
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
        </style>
    `;
    
    // 2초 후 서버 콘텐츠 로드
    setTimeout(() => {
        const serverUrl = 'https://dovie-hello2sangyun.replit.app';
        
        // iframe으로 서버 콘텐츠 로드 (네이티브 앱 내에서 실행)
        document.body.innerHTML = `
            <iframe 
                src="${serverUrl}" 
                style="
                    width: 100%;
                    height: 100vh;
                    border: none;
                    margin: 0;
                    padding: 0;
                "
                onload="console.log('Dovie Messenger 로드 완료')"
                onerror="showErrorMessage()"
            ></iframe>
        `;
    }, 2000);
}

function showErrorMessage() {
    document.body.innerHTML = `
        <div style="
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            font-family: -apple-system, BlinkMacSystemFont, sans-serif;
            text-align: center;
            padding: 20px;
        ">
            <div style="
                background: rgba(255,255,255,0.1);
                padding: 40px;
                border-radius: 20px;
                backdrop-filter: blur(10px);
            ">
                <h1 style="margin: 0 0 20px 0;">연결 실패</h1>
                <p style="margin: 0;">서버에 연결할 수 없습니다.</p>
                <p style="margin: 10px 0 0 0; font-size: 14px; opacity: 0.8;">네트워크 연결을 확인해주세요.</p>
                <button onclick="loadDovieMessenger()" style="
                    margin-top: 20px;
                    padding: 12px 24px;
                    background: rgba(255,255,255,0.2);
                    border: none;
                    border-radius: 10px;
                    color: white;
                    font-weight: bold;
                    cursor: pointer;
                ">다시 시도</button>
            </div>
        </div>
    `;
}