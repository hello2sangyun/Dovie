// Dovie Messenger iOS 앱 - 현재 배포된 서버 연결
document.addEventListener('DOMContentLoaded', function() {
    console.log('iOS 앱 시작 - 서버 연결 중...');
    
    // 현재 배포된 서버로 연결
    setTimeout(() => {
        const serverUrl = 'https://vault-messenger-1-hello2sangyun.replit.app';
        console.log('서버 연결:', serverUrl);
        window.location.href = serverUrl;
    }, 1500);
});